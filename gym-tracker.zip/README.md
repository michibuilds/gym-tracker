# Gym Tracker

Eine lokale Web-App zum Tracken von Kraft- und Calisthenics-Training. Läuft komplett im Browser, alle Daten bleiben auf deinem Gerät.

## Auf dem iPhone testen — in 3 Schritten

### 1. Auf GitHub hochladen
- Neues Repository auf github.com erstellen (z. B. `gym-tracker`), **Public**.
- `index.html` hochladen (Drag & Drop im Browser auf „Add file → Upload files“).

### 2. GitHub Pages aktivieren
- Im Repo: **Settings → Pages**.
- Unter „Branch“ `main` wählen, Ordner `/ (root)`, **Save**.
- Nach ~1 Minute erscheint die Adresse: `https://DEIN-NAME.github.io/gym-tracker/`

### 3. Auf dem iPhone öffnen & installieren
- Adresse in **Safari** öffnen.
- Teilen-Symbol → **„Zum Home-Bildschirm“**.
- Jetzt startet die App im Vollbild wie eine echte App.

## Funktionen
- **Training:** Trainingstag wählen, durch Übungen wischen (vertikal).
- **Werte:** kg und Wdh durch Hoch-/Runter-Wischen auf dem Feld ändern.
- **Satz erledigt:** Satz nach rechts wischen (mit Widerstand).
- **Timer:** Halte-Timer für Zeitübungen mit Alarmton (4 Töne wählbar in Einstellungen).
- **Verlauf:** Gesamt-Tonnage + Meilensteine (Hauskatze → Verkehrsflugzeug).
- **Eigene Tage:** im Plus-Button Übungen nach Kraft/Calisthenics auswählen.
- **Backup:** Export/Import als Datei (Einstellungen), gegen Datenverlust beim Browser-Löschen.

## Wichtig zur Speicherung
Die Daten liegen im `localStorage` deines Browsers. Sie bleiben erhalten, solange du die Safari-Website-Daten nicht löschst. Mach gelegentlich einen **Export** (Einstellungen → Backup), um auf Nummer sicher zu gehen.

## Lokal testen (ohne GitHub)
`index.html` einfach im Browser öffnen. Touch-Gesten funktionieren am besten auf dem Handy; am Desktop kannst du die Werte auch mit gedrückter Maus hoch/runter ziehen.
